package menuinteractivo;

import java.util.Scanner;

public class MenuInteractivo {

    public static void main(String[] args) {

        // 1. Crear el objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        int opcion;

        // 2. Estructura do-while para asegurar que el menú se muestre al menos una vez
        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Saludar");
            System.out.println("2. Sumar dos números");
            System.out.println("3. Salir");
            System.out.print("Elige una opción (1-3): ");

            // Leer la opción ingresada por el usuario
            opcion = scanner.nextInt();

            // Estructura switch para evaluar la opción elegida
            switch (opcion) {
            case 1:
                    System.out.println("\n!Hola Bienvenido a este programa en Java.");
                    break;

            case 2:
                    System.out.println("Ingresa el primer número: ");
                    double num1 = scanner.nextDouble();
                    
                    System.out.println("Ingresa el segundo número: ");
                    double num2 = scanner.nextDouble();
                    
                    double resultado = num1 + num2;
                    System.out.println("El resultado de la suma es: " + resultado);
                    break;
            case 3:
                    System.out.println("\nSaliendo del Programa. ¡Hasta Luego!");
                    break;
            
            default:
                System.out.println("Opción no válida. Por favor, elige un número del 1 al 3.");
                break;
                    

            }

        }while (opcion !=3 );
        
        scanner.close();
        
    }

}
